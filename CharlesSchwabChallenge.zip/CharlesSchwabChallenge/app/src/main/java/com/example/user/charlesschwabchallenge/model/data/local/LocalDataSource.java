package com.example.user.charlesschwabchallenge.model.data.local;


public class LocalDataSource {

    PizzaDatabase pizzaDatabase;
    PizzaDao pizzaDao;

    public LocalDataSource() {


    }
}
