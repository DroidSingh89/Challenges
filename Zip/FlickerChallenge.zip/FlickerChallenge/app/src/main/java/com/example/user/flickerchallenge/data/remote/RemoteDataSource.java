package com.example.user.flickerchallenge.data.remote;

import com.example.user.flickerchallenge.model.FlickerData;

import io.reactivex.Observable;
import okhttp3.OkHttpClient;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Call;
import retrofit2.Retrofit;
import retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.http.GET;
import retrofit2.http.Query;

public class RemoteDataSource {

    private static final String BASE_URL = "http://api.flickr.com/";
    private static final String QUERY_TAG = "kitten";
    private static final String QUERY_FORMAT = "json";
    private static final String QUERY_NOJSONCALLBACK = "1";
    static final String PATH = "services/feeds/photos_public.gne";


    private static Retrofit create(){

        HttpLoggingInterceptor logging = new HttpLoggingInterceptor();
        logging.setLevel(HttpLoggingInterceptor.Level.BASIC);
        OkHttpClient client = new OkHttpClient.Builder()
                .addInterceptor(logging)
                .build();


        return new Retrofit.Builder()
                .client(client)
                .baseUrl(BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .addCallAdapterFactory(RxJava2CallAdapterFactory.create())
                .build();

    }

    public static Observable<FlickerData> getResponse(){

        Retrofit retrofit = create();
        FlickerService flickerService = retrofit.create(FlickerService.class);
        return flickerService.getImageList(QUERY_TAG, QUERY_FORMAT, QUERY_NOJSONCALLBACK);

    }


    public interface FlickerService{

        @GET(PATH)
        Observable<FlickerData> getImageList(@Query("tag") String tag, @Query("format") String format, @Query("nojsoncallback") String noJsonCallback);
    }


}
