package com.example.user.flickerchallenge.view.flickeractivity;

import com.example.user.flickerchallenge.BasePresenter;
import com.example.user.flickerchallenge.BaseView;
import com.example.user.flickerchallenge.model.Item;

import java.util.List;


public interface FlickerActivityContract {


    interface View extends BaseView{


        void onListUpdated(List<Item> items);

    }


    interface Presenter extends BasePresenter<View>{

        void updateImageList();



    }
}
