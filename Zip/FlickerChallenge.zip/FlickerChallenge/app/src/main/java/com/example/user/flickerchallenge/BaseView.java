package com.example.user.flickerchallenge;


public interface BaseView  {

    void showError(String e);
}
