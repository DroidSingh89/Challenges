package com.example.user.flickerchallenge.view.flickeractivity;

import android.util.Log;

import com.example.user.flickerchallenge.data.remote.RemoteDataSource;
import com.example.user.flickerchallenge.model.FlickerData;

import io.reactivex.Observer;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class FlickerActivityPresenter implements FlickerActivityContract.Presenter {


    private FlickerActivityContract.View view;

    @Override
    public void attachView(FlickerActivityContract.View view) {

        this.view = view;
    }

    @Override
    public void removeView() {

        this.view = null;

    }

    @Override
    public void updateImageList() {


        RemoteDataSource.getResponse()
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Observer<FlickerData>() {
                    @Override
                    public void onSubscribe(Disposable d) {

                    }

                    @Override
                    public void onNext(FlickerData flickerData) {

                        view.onListUpdated(flickerData.getItems());
                    }

                    @Override
                    public void onError(Throwable e) {

                    }

                    @Override
                    public void onComplete() {

                    }
                });


    }
}
