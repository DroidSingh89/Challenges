package com.example.admin.ridecellchallenge.model.data.local;

import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.Query;

import com.example.admin.ridecellchallenge.model.bean.Photo;

import java.util.List;

import io.reactivex.Completable;
import io.reactivex.Flowable;

@Dao
public interface PhotoDao {

    @Insert
    void insertAll(List<Photo> photos);

    @Query("Select * from Photo")
    Flowable<List<Photo>> getPhotos();


}
