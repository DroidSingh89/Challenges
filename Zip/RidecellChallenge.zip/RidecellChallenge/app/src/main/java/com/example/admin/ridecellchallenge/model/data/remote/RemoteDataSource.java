package com.example.admin.ridecellchallenge.model.data.remote;

import android.content.Context;

import com.example.admin.ridecellchallenge.model.bean.FlickerResponse;
import com.example.admin.ridecellchallenge.model.bean.Photo;
import com.example.admin.ridecellchallenge.utils.ImageUtils;

import java.util.List;

import io.reactivex.Observable;
import io.reactivex.Observer;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;
import okhttp3.Cache;
import okhttp3.OkHttpClient;
import retrofit2.Retrofit;
import retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory;
import retrofit2.converter.gson.GsonConverterFactory;

public class RemoteDataSource {

    private static final String BASE_URL = "https://api.flickr.com";
    private static final String METHOD = "flickr.photos.search";
    private static final String API_KEY = "6bf318919bbbc455f3573d18798a58e3";
    private static final String FORMAT = "json";
    private static final String NOJSONCALLBACK = "1";

    private Context context;

    public RemoteDataSource(Context context) {
        this.context = context;
    }

    private Retrofit createRetrofit() {


        return new Retrofit.Builder()
                .baseUrl(BASE_URL)
                .client(getClient())
                .addConverterFactory(GsonConverterFactory.create())
                .addCallAdapterFactory(RxJava2CallAdapterFactory.create())
                .build();


    }

    private OkHttpClient getClient() {

//        setup autocaching
        Cache cache = new Cache(context.getCacheDir(), 10 * 1024 * 1024);
        OkHttpClient client = new OkHttpClient.Builder()
                .cache(cache)
                .build();

        return client;

    }

    private Observable<FlickerResponse> getPhotoObservable(String tags) {

        return createRetrofit().create(FlickerService.class).getPhotos(METHOD, API_KEY, tags, FORMAT, NOJSONCALLBACK);

    }

    public void getPhotos(String tags, final Callback callback) {

        getPhotoObservable(tags)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .map(ImageUtils.mapWithUrls())
                .subscribe(new Observer<List<Photo>>() {
                    @Override
                    public void onSubscribe(Disposable d) {

                    }

                    @Override
                    public void onNext(List<Photo> photos) {

                        callback.onSuccess(photos);

                    }

                    @Override
                    public void onError(Throwable e) {
                        callback.onFailure(e.toString());

                    }

                    @Override
                    public void onComplete() {

                    }
                });

    }

    public interface Callback {

        void onSuccess(List<Photo> photos);

        void onFailure(String error);
    }


}

