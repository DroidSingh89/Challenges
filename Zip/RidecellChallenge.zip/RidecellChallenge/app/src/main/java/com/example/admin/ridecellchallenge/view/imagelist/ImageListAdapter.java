package com.example.admin.ridecellchallenge.view.imagelist;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.admin.ridecellchallenge.R;
import com.example.admin.ridecellchallenge.model.bean.Photo;
import com.example.admin.ridecellchallenge.view.imagedetail.ImageDetailActivity;

import java.util.List;

public class ImageListAdapter extends RecyclerView.Adapter<ImageListAdapter.ViewHolder> {

    private static final String TAG = "something";

    private List<Photo> photos;

    ImageListAdapter(List<Photo> photos) {
        this.photos = photos;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_list, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder viewHolder, int position) {

        Photo photo = photos.get(position);
        Glide.with(viewHolder.itemView.getContext()).load(photo.getImageUrl()).into(viewHolder.ivPhoto);
        viewHolder.tvTitle.setText(photo.getTitle());

        setupTags(viewHolder, photo);

    }

    private void setupTags(ViewHolder viewHolder, Photo photo) {

        int server = Integer.parseInt(photo.getServer());
        if ((server % 2) == 0) {
            viewHolder.isFamily.setVisibility(View.GONE);

        }

        if ((server % 3) == 0) {
            viewHolder.isFriend.setVisibility(View.GONE);

        }

    }

    @Override
    public int getItemCount() {
        return photos.size();
    }

    public void updateList(List<Photo> photoList) {
        this.photos.clear();
        this.photos.addAll(photoList);
        notifyDataSetChanged();
    }

    class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        TextView tvTitle;
        ImageView ivPhoto;

        TextView isPublic;
        TextView isFamily;
        TextView isFriend;


        ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvTitle = itemView.findViewById(R.id.tvTitle);
            ivPhoto = itemView.findViewById(R.id.ivPhoto);

            isPublic = itemView.findViewById(R.id.tvPublic);
            isFamily = itemView.findViewById(R.id.tvFamily);
            isFriend = itemView.findViewById(R.id.tvFriend);
            itemView.setOnClickListener(this);

        }

        @Override
        public void onClick(View view) {
            Intent intent = new Intent(view.getContext(), ImageDetailActivity.class);
            intent.putExtra("photo", photos.get(getAdapterPosition()));
            view.getContext().startActivity(intent);
        }
    }
}
