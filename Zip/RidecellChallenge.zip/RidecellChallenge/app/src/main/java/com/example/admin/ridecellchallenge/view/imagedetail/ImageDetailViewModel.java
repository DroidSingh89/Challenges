package com.example.admin.ridecellchallenge.view.imagedetail;

import android.arch.lifecycle.LiveData;
import android.arch.lifecycle.MutableLiveData;
import android.arch.lifecycle.ViewModel;

import com.example.admin.ridecellchallenge.model.bean.Photo;

public class ImageDetailViewModel extends ViewModel {

    private MutableLiveData<Photo> photoMutableLiveData;


    public ImageDetailViewModel() {
        photoMutableLiveData = new MutableLiveData<>();

    }

    public LiveData<Photo> getPhotoDetails(Photo photo) {
        photoMutableLiveData.setValue(photo);
        return photoMutableLiveData;

    }
}
