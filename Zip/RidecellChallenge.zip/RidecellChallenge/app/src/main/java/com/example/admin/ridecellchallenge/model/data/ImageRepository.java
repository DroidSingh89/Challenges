package com.example.admin.ridecellchallenge.model.data;

import android.arch.lifecycle.LiveData;
import android.arch.lifecycle.MutableLiveData;
import android.content.Context;

import com.example.admin.ridecellchallenge.model.bean.Photo;
import com.example.admin.ridecellchallenge.model.data.local.LocalDataSource;
import com.example.admin.ridecellchallenge.model.data.remote.RemoteDataSource;

import java.util.List;

public class ImageRepository {


    private LocalDataSource localDataSource;
    private RemoteDataSource remoteDataSource;

    private MutableLiveData<List<Photo>> photoLiveData;

    public ImageRepository(Context context) {

        photoLiveData = new MutableLiveData<>();
        localDataSource = new LocalDataSource(context);
        remoteDataSource = new RemoteDataSource(context);

    }

    public LiveData<List<Photo>> getImageData(String tag) {

        remoteDataSource.getPhotos(tag, new RemoteDataSource.Callback() {
            @Override
            public void onSuccess(List<Photo> photos) {
                photoLiveData.setValue(photos);
            }

            @Override
            public void onFailure(String error) {

            }
        });

        return photoLiveData;

    }



}
