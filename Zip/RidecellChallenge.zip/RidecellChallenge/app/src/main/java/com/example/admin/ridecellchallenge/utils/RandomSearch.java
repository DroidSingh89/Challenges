package com.example.admin.ridecellchallenge.utils;


import java.util.ArrayList;
import java.util.List;
import java.util.Random;


public class RandomSearch {

    public static String getRandomTag() {

        List<String> randomTags = new ArrayList<>();

        randomTags.add("Cat");
        randomTags.add("car");
        randomTags.add("food");
        randomTags.add("beach");
        randomTags.add("sports");
        randomTags.add("shows");
        randomTags.add("football");
        randomTags.add("shirt");

        return randomTags.get(new Random().nextInt(randomTags.size()));
    }
}
