package com.example.admin.ridecellchallenge.view.imagedetail;

import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.admin.ridecellchallenge.R;
import com.example.admin.ridecellchallenge.model.bean.Photo;

public class ImageDetailActivity extends AppCompatActivity {

    private TextView tvTitle;
    private ImageView ivPhoto;
    private ImageDetailViewModel viewModel;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_image_detail);
        bindView();

        viewModel = ViewModelProviders.of(this).get(ImageDetailViewModel.class);
        viewModel.getPhotoDetails((Photo) getIntent().getSerializableExtra("photo"))
                .observe(this, new Observer<Photo>() {
                    @Override
                    public void onChanged(@Nullable Photo photo) {
                        if (photo != null) {
                            tvTitle.setText(photo.getTitle());
                            Glide.with(getApplicationContext()).load(photo.getImageUrl()).into(ivPhoto);
                        }
                    }
                });
    }

    private void bindView() {
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Photo added to favorites", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });

        tvTitle = findViewById(R.id.tvTitle);
        ivPhoto = findViewById(R.id.ivPhoto);
    }


}
