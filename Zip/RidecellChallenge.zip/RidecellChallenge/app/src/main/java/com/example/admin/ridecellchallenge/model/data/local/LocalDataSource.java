package com.example.admin.ridecellchallenge.model.data.local;

import android.arch.persistence.room.Room;
import android.content.Context;

public class LocalDataSource {

    Context context;
    private final ImageDatabase imageDatabase;

    public LocalDataSource(Context context) {
        this.context = context;

        imageDatabase = Room.databaseBuilder(context.getApplicationContext(), ImageDatabase.class, "ImageDatabase").build();
    }


    public void getPhotos(String tag) {


    }

}
