package com.example.admin.ridecellchallenge.view.imagelist;

import android.app.Application;
import android.arch.lifecycle.AndroidViewModel;
import android.arch.lifecycle.LiveData;
import android.arch.lifecycle.ViewModel;
import android.support.annotation.NonNull;

import com.example.admin.ridecellchallenge.model.bean.Photo;
import com.example.admin.ridecellchallenge.model.data.ImageRepository;

import java.util.List;

public class ImageListViewModel extends AndroidViewModel{

    private ImageRepository imageRepository;


    ImageListViewModel(@NonNull Application application) {
        super(application);
        imageRepository = new ImageRepository(application.getApplicationContext());
    }

    public LiveData<List<Photo>> getImages(String tag) {

        return imageRepository.getImageData(tag);


    }
}
