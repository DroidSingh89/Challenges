package com.example.admin.ridecellchallenge.model.data.remote;


import com.example.admin.ridecellchallenge.model.bean.FlickerResponse;

import io.reactivex.Observable;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface FlickerService {

    @GET("/services/rest/")
    Observable<FlickerResponse> getPhotos(@Query("method") String method,
                                          @Query("api_key") String apiKey,
                                          @Query("tags") String tags,
                                          @Query("format") String format,
                                          @Query("nojsoncallback") String noJsonCallback);

}
