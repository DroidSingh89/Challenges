package com.example.admin.ridecellchallenge.utils;

import com.example.admin.ridecellchallenge.model.bean.FlickerResponse;
import com.example.admin.ridecellchallenge.model.bean.Photo;

import java.util.List;

import io.reactivex.functions.Function;

public class ImageUtils {

    private static List<Photo> updateImageUrls(List<Photo> rawList) {

        String farm_id;
        String server_id;
        String id;
        String secret;
        String photoUrl;

        for (Photo photo : rawList) {
            farm_id = String.valueOf(photo.getFarm());
            id = photo.getId();
            server_id = photo.getServer();
            secret = photo.getSecret();

            //create image url using photo details
            photoUrl = "https://farm" + farm_id + ".staticflickr.com/" + server_id + "/" + id + "_" + secret + ".jpg";
            photo.setImageUrl(photoUrl);

        }
        return rawList;
    }

    public static Function<FlickerResponse, List<Photo>> mapWithUrls() {
        return new Function<FlickerResponse, List<Photo>>() {
            @Override
            public List<Photo> apply(FlickerResponse flickerResponse) throws Exception {

                return updateImageUrls(flickerResponse.getPhotos().getPhoto());
            }
        };
    }

}
